var cards = [
	{rank: "queen",suit: "heart",cardImage:"images/queen-of-hearts.png"}, 
	{rank: "queen", suit: "diamond", cardImage: "images/queen-of-diamonds.png"}, 
	{rank: "king", suit: "heart", cardImage: "images/king-of-hearts.png"}, 
	{rank: "king", suit: "diamond", cardImage: "images/king-of-diamonds.png"}
];

var cardsInPlay = [];

var createBoard = function(){
	for (var i = 0; i < cards.length;  i++) {
		var cardElement = document.createElement('img');
		cardElement.setAttribute("src", "images/back.png");
		cardElement.setAttribute("data-id", i);
		cardElement.addEventListener("click", flipCard);
		document.getElementById("game-board").appendChild(cardElement);
	}
}

var checkForMatch = function(){
	if (cardsInPlay[cards.rank] === cardsInPlay[cards.rank]) {
		console.log("You found a match!");
	} else {
		console.log("Sorry, try again.");
	}
	console.log(cards);
};

var flipCard = function(){
	var cardId = this.getAttribute("data-id");
	this.setAttribute("src", cards[cardId].cardImage);
	cardsInPlay.push(cards[cardId].rank);
	checkForMatch();
	console.log("User has flipped " + cards[cardId].rank);
};




createBoard();


